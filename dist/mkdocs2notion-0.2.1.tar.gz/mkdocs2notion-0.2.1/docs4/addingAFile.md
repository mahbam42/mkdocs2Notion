# New File 

This is a test to see what happens when there are additional files added and `--fresh` isn't used. *Also I made some refinements to the progress bar in the CLI* ~~So we're checking that out~~ 

- [ ] Did it work? 
- [ ] Mark it off! 