# Some Custom Test Blocks 

## Definition List
term
: definition
Foo
: bar 
Lorem
: Ipsum
: other meaning

Strikethrough	~~The world is flat.~~

Task List	
- [x] Write the press release
- [ ] Update the website
- [ ] Contact the media

| table | with | headers |
|----|----|----|
| the | first | row |
| second | goes | here |
