# Welcome

This is the Docs2 sample home page.
