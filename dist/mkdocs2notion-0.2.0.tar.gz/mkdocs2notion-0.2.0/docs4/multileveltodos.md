# Multilevel ToDos! 

1. Come up with a plan 
    - [ ] Think
    - [ ] Ask ChatGPT
2. Do the Plan
    - [ ] Go 
    - [ ] Find it
    - [ ] pay a heavy price
3. ???
    - [ ] Revise the list
        - [ ] Put in a sub task
4. Profit 
    - [ ] Shut up and take my money
    - this one isn't a task
    - [ ] Mark this one done if the last line didn't break anything... 